/**************************
*Julio Reyes *
*CPSC2310 Lab7 *
*UserName: jcreyes*
*Lab Section: 003*
/*************************/
#include "functions.h"


int main()
{
    printf("%d\n", isArithmetic());

    printf("%d\n", isOddOne(128));

    printf("%d\n", isOddOne(64));

    return 0;
}
