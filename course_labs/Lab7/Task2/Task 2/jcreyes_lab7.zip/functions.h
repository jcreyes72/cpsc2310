/**************************
*Julio Reyes *
*CPSC2310 Lab7 *
*UserName: jcreyes*
*Lab Section: 003*
/*************************/
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

int isArithmetic();
int isOddOne(unsigned);

#endif

