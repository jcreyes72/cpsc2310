#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>

void inplace_swap(int *x, int *y);

void reverse_array(int a[], int cnt);


int fun1(unsigned word);

int fun2(unsigned word);


#endif // FUNCTIONS_H_INCLUDED
